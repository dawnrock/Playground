document.getElementById("name").value = "Jose Manuel";
document.getElementById("lastname").value = "Alba Peña";
document.getElementById("avatar").src = "./img/male.png";
